# Plafond LED – Android-app

Bediening van de Tasmota-schakelaar (standaard op 10.10.100.114): aan/uit, Tasmota-tijd en twee schema's
(vaste tijd, zonsopkomst of zonsondergang). De app doet de verzoeken zelf, dus CORS speelt geen rol.

## APK laten bouwen door GitHub
1. Zet deze bestanden in een GitHub-repository (inclusief de map `.github/workflows`).
2. GitHub bouwt de app automatisch bij elke wijziging (tab **Actions**, duurt een paar minuten).
3. Open op je telefoon de repository → **Releases** → nieuwste build → download `PlafondLED.apk`.
4. Installeer de APK (Android vraagt eenmalig toestemming voor "onbekende apps").

## Aanpassen
De pagina staat in `app/src/main/assets/index.html`. Het IP-adres kun je ook in de app wijzigen onder **Instellingen**.
