package nl.dijkman.plafondled;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/** Opent bij het plaatsen (of opnieuw instellen) van een schakelaar-widget: kies de schakelaar. */
public class WidgetConfigActivity extends Activity {

    private int wid = AppWidgetManager.INVALID_APPWIDGET_ID;

    private int dp(float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);   // terug/annuleren = geen widget
        Bundle ex = getIntent().getExtras();
        if (ex != null) wid = ex.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(12), dp(16), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF1F1F1F);
        bg.setCornerRadius(dp(18));
        col.setBackground(bg);

        TextView title = text("Choose a switch for this widget", 17, 0xFFEEEAE2, true);
        title.setPadding(dp(8), 0, dp(8), dp(8));
        col.addView(title);

        JSONArray devs = DeviceWidget.devices(this);
        String cur = DeviceWidget.ipFor(this, wid);
        if (devs.length() == 0) {
            TextView t = text("No switches saved yet.\n\nOpen Tasmota Scan & Control, scan the network, then add the widget again.", 14, 0xFF9A958C, false);
            t.setPadding(dp(8), dp(4), dp(8), dp(12));
            col.addView(t);
            TextView open = text("Open the app", 15, 0xFF3A2700, true);
            open.setGravity(Gravity.CENTER);
            open.setPadding(dp(12), dp(12), dp(12), dp(12));
            GradientDrawable ob = new GradientDrawable();
            ob.setColor(0xFFE8A317);
            ob.setCornerRadius(dp(12));
            open.setBackground(ob);
            open.setOnClickListener(v -> {
                startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                finish();
            });
            col.addView(open);
        } else {
            String lastGroup = null;
            for (int i = 0; i < devs.length(); i++) {
                JSONObject d = devs.optJSONObject(i);
                if (d == null) continue;
                String g = d.optString("group", "");
                if (!g.equals(lastGroup)) {
                    lastGroup = g;
                    TextView h = text((g.isEmpty() ? "Not in a group" : g).toUpperCase(), 11, 0xFF9A958C, true);
                    h.setPadding(dp(8), dp(12), dp(8), dp(4));
                    h.setLetterSpacing(0.06f);
                    col.addView(h);
                }
                col.addView(row(d, d.optString("ip").equals(cur)));
            }
        }

        ScrollView sv = new ScrollView(this);
        sv.addView(col);
        setContentView(sv);
        getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        getWindow().setLayout(Math.min(getResources().getDisplayMetrics().widthPixels - dp(32), dp(420)),
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private View row(JSONObject d, boolean selected) {
        final String ip = d.optString("ip");
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(10), dp(10), dp(10));
        GradientDrawable rb = new GradientDrawable();
        rb.setColor(selected ? 0x22E8A317 : 0x00000000);
        rb.setCornerRadius(dp(10));
        if (selected) rb.setStroke(dp(1.5f), 0xFFE8A317);
        r.setBackground(rb);

        ImageView ic = new ImageView(this);
        Bitmap bm = DeviceWidget.iconBitmap(d);
        if (bm != null) ic.setImageBitmap(bm); else ic.setImageResource(R.drawable.ic_dev_bulb);
        ic.setColorFilter(d.optBoolean("water", false) ? DeviceWidget.BLUE : 0xFFEEEAE2);
        r.addView(ic, new LinearLayout.LayoutParams(dp(26), dp(26)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.setPadding(dp(14), 0, 0, 0);
        tx.addView(text(DeviceWidget.label(d, ip), 15, 0xFFEEEAE2, true));
        TextView ipT = text(ip, 11, 0xFF9A958C, false);
        ipT.setTypeface(Typeface.MONOSPACE);
        tx.addView(ipT);
        r.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        r.setOnClickListener(v -> choose(ip));
        return r;
    }

    private void choose(String ip) {
        DeviceWidget.setIp(this, wid, ip);
        DeviceWidget.render(this, AppWidgetManager.getInstance(this), wid);
        DeviceWidget.refreshOne(getApplicationContext(), ip);
        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid));
        finish();
    }
}
