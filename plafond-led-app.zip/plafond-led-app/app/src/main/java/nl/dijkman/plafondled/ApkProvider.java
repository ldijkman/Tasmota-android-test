package nl.dijkman.plafondled;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Minimale provider: geeft alleen de gedownloade update (cache/update/update.apk) door aan het
 * Android-installatiescherm. Alleen-lezen, niet van buiten de app te openen (exported=false).
 */
public class ApkProvider extends ContentProvider {

    static final String AUTHORITY = "nl.dijkman.plafondled.apk";
    static final String MIME = "application/vnd.android.package-archive";

    static File apkFile(android.content.Context c) {
        File dir = new File(c.getCacheDir(), "update");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, "update.apk");
    }

    static Uri uri() { return Uri.parse("content://" + AUTHORITY + "/update.apk"); }

    @Override public boolean onCreate() { return true; }

    @Override public String getType(Uri uri) { return MIME; }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"update.apk".equals(uri.getLastPathSegment())) throw new FileNotFoundException();
        return ParcelFileDescriptor.open(apkFile(getContext()), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String sel, String[] args, String sort) {
        File f = apkFile(getContext());
        MatrixCursor c = new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE});
        c.addRow(new Object[]{"update.apk", f.length()});
        return c;
    }

    @Override public Uri insert(Uri uri, ContentValues v) { return null; }
    @Override public int delete(Uri uri, String s, String[] a) { return 0; }
    @Override public int update(Uri uri, ContentValues v, String s, String[] a) { return 0; }
}
