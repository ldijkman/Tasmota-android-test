package nl.dijkman.plafondled;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Homescreen-widget voor één Tasmota-schakelaar.
 * Bij het plaatsen kies je de schakelaar (WidgetConfigActivity); tik = aan/uit.
 * De lijst met schakelaars (naam, wachtwoord, pictogram) krijgt de widget van de app
 * via Tasmota.syncWidgets(); de toestand wordt hier zelf bij Tasmota opgevraagd.
 */
public class DeviceWidget extends AppWidgetProvider {

    static final String ACTION_TOGGLE = "nl.dijkman.plafondled.DEV_TOGGLE";
    static final String ACTION_NET = "nl.dijkman.plafondled.DEV_NET";
    private static volatile long lastNet = 0;
    static final String PREFS = "devwidgets";
    static final ExecutorService POOL = Executors.newCachedThreadPool();

    static final int YELLOW = 0xFFE8A317, BLUE = 0xFF3FA9F5, GREY = 0xFF9A958C, ERR = 0xFFE06A5F;

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ---------- gegevens ----------

    /** Opgeslagen lijst uit de app: [{ip, name, group, pw, water, png}] */
    static JSONArray devices(Context c) {
        try { return new JSONArray(prefs(c).getString("devs", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    static JSONObject device(Context c, String ip) {
        if (ip == null) return null;
        JSONArray a = devices(c);
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && ip.equals(o.optString("ip"))) return o;
        }
        return null;
    }

    static void saveDevices(Context c, String json) {
        prefs(c).edit().putString("devs", json == null ? "[]" : json).apply();
        updateAll(c);
    }

    static String ipFor(Context c, int wid) { return prefs(c).getString("w" + wid, null); }

    static void setIp(Context c, int wid, String ip) { prefs(c).edit().putString("w" + wid, ip).apply(); }

    static String state(Context c, String ip) { return prefs(c).getString("st_" + ip, ""); }

    static void putState(Context c, String ip, String st) { prefs(c).edit().putString("st_" + ip, st).apply(); }

    /** Vanuit de app: bekende toestand doorgeven ("on" / "off") */
    static void setState(Context c, String ip, String st) {
        if (ip == null || st == null || st.equals(state(c, ip))) return;
        putState(c, ip, st);
        updateForIp(c, ip);
    }

    // ---------- widget-levenscyclus ----------

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        listenForNetworkChanges(ctx);
        for (int id : ids) render(ctx, mgr, id);
        // toestand ophalen bij de schakelaars (op de achtergrond)
        final PendingResult pr = goAsync();
        final Context app = ctx.getApplicationContext();
        POOL.execute(() -> {
            try { refreshAll(app); } finally { pr.finish(); }
        });
    }

    @Override
    public void onEnabled(Context ctx) { listenForNetworkChanges(ctx); }

    @Override
    public void onDisabled(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            try { ctx.getSystemService(ConnectivityManager.class).unregisterNetworkCallback(netIntent(ctx)); }
            catch (Exception ignored) { }
        }
    }

    private static PendingIntent netIntent(Context ctx) {
        Intent i = new Intent(ctx, DeviceWidget.class).setAction(ACTION_NET);
        return PendingIntent.getBroadcast(ctx, 7, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
    }

    /** Android seint de widget bij elke wifi-wijziging, ook als de app dicht is (Android 8+) */
    static void listenForNetworkChanges(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            ConnectivityManager cm = ctx.getSystemService(ConnectivityManager.class);
            // elk netwerk (wifi én mobiel): als wifi wegvalt, wordt mobiel actief en horen we dat ook
            NetworkRequest req = new NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build();
            PendingIntent pi = netIntent(ctx);
            try { cm.unregisterNetworkCallback(pi); } catch (Exception ignored) { }
            cm.registerNetworkCallback(req, pi);
        } catch (Exception ignored) { }
    }

    @Override
    public void onDeleted(Context ctx, int[] ids) {
        SharedPreferences.Editor e = prefs(ctx).edit();
        for (int id : ids) e.remove("w" + id);
        e.apply();
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (ACTION_TOGGLE.equals(intent.getAction())) {
            final int wid = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            final String ip = ipFor(ctx, wid);
            if (ip == null) { openApp(ctx); return; }
            final Context app = ctx.getApplicationContext();
            putState(app, ip, "busy");
            updateForIp(app, ip);
            final PendingResult pr = goAsync();
            POOL.execute(() -> {
                try {
                    String[] w = WifiWidget.current(app);
                    if (w[1] == null || w[1].isEmpty()) putState(app, ip, "nowifi");
                    else {
                        String st = request(app, ip, "Power TOGGLE");
                        if ("err".equals(st) && !prefix(ip).equals(prefix(w[1]))) st = "otherwifi";
                        putState(app, ip, st);
                    }
                }
                finally { updateForIp(app, ip); pr.finish(); }
            });
            return;
        }
        if (ACTION_NET.equals(intent.getAction())) {
            // wifi aan/uit/ander netwerk: kort wachten tot het IP er is, dan opnieuw kijken
            long now = System.currentTimeMillis();
            if (now - lastNet < 4000) return;   // Android stuurt er vaak meerdere tegelijk
            lastNet = now;
            final Context app = ctx.getApplicationContext();
            final PendingResult pr = goAsync();
            POOL.execute(() -> {
                try {
                    Thread.sleep(2500);
                    refreshAll(app);
                } catch (InterruptedException ignored) {
                } finally { pr.finish(); }
            });
            return;
        }
        super.onReceive(ctx, intent);
    }

    private static void openApp(Context ctx) {
        Intent i = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    /** Toestand van alle schakelaars met een widget opvragen */
    static void refreshAll(Context c) {
        Set<String> ips = new LinkedHashSet<>();
        for (int id : ids(c)) { String ip = ipFor(c, id); if (ip != null) ips.add(ip); }
        String[] w = WifiWidget.current(c);   // {ssid, ip, status}
        boolean wifi = w[1] != null && !w[1].isEmpty();
        for (String ip : ips) {
            putState(c, ip, wifi ? reach(c, ip, w[1]) : "nowifi");
            updateForIp(c, ip);
        }
    }

    static void refreshOne(Context c, String ip) {
        POOL.execute(() -> {
            String[] w = WifiWidget.current(c);
            putState(c, ip, w[1] == null || w[1].isEmpty() ? "nowifi" : reach(c, ip, w[1]));
            updateForIp(c, ip);
        });
    }

    /** Toestand opvragen; lukt het niet en zit de telefoon in een ander subnet: "otherwifi" */
    static String reach(Context c, String ip, String phoneIp) {
        String st = request(c, ip, "Power");
        if ("err".equals(st) && !prefix(ip).equals(prefix(phoneIp))) return "otherwifi";
        return st;
    }

    static String prefix(String ip) {
        int i = ip == null ? -1 : ip.lastIndexOf('.');
        return i < 0 ? "" : ip.substring(0, i);
    }

    // ---------- tekenen ----------

    static int[] ids(Context c) {
        return AppWidgetManager.getInstance(c).getAppWidgetIds(new ComponentName(c, DeviceWidget.class));
    }

    static void updateAll(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) render(c, mgr, id);
    }

    static void updateForIp(Context c, String ip) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        for (int id : ids(c)) if (ip.equals(ipFor(c, id))) render(c, mgr, id);
    }

    static String label(JSONObject d, String ip) {
        String n = d == null ? "" : d.optString("name", "");
        return n.isEmpty() ? ip : n;
    }

    static Bitmap iconBitmap(JSONObject d) {
        try {
            String b64 = d == null ? "" : d.optString("png", "");
            if (b64.isEmpty()) return null;
            byte[] b = Base64.decode(b64, Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(b, 0, b.length);
        } catch (Exception e) { return null; }
    }

    static void render(Context c, AppWidgetManager mgr, int wid) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_device);
        String ip = ipFor(c, wid);
        JSONObject d = device(c, ip);
        String st = ip == null ? "" : state(c, ip);
        boolean on = "on".equals(st), water = d != null && d.optBoolean("water", false);
        int col = on ? (water ? BLUE : YELLOW) : ("err".equals(st) || "locked".equals(st)) ? ERR : GREY;

        Bitmap bm = iconBitmap(d);
        if (bm != null) v.setImageViewBitmap(R.id.wd_icon, bm);
        else v.setImageViewResource(R.id.wd_icon, R.drawable.ic_dev_bulb);
        v.setInt(R.id.wd_icon, "setColorFilter", on ? col : 0xFF8A857C);

        v.setTextViewText(R.id.wd_name, ip == null ? "Choose switch" : label(d, ip));
        String txt = on ? "On" : "off".equals(st) ? "Off" : "busy".equals(st) ? "…"
                : "locked".equals(st) ? "Password?" : "err".equals(st) ? "Not reachable"
                : "nowifi".equals(st) ? "No wifi" : "otherwifi".equals(st) ? "Other wifi" : "Tap to switch";
        v.setTextViewText(R.id.wd_state, txt);
        v.setTextColor(R.id.wd_state, col);
        v.setInt(R.id.wd_root, "setBackgroundResource",
                on ? (water ? R.drawable.widget_dev_on_w : R.drawable.widget_dev_on) : R.drawable.widget_dev_off);

        Intent t = new Intent(c, DeviceWidget.class).setAction(ACTION_TOGGLE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid)
                .setData(Uri.parse("tasmota-widget://" + wid));   // uniek per widget
        v.setOnClickPendingIntent(R.id.wd_root, PendingIntent.getBroadcast(c, wid, t,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        mgr.updateAppWidget(wid, v);
    }

    // ---------- Tasmota ----------

    /** Stuurt een commando, geeft "on" | "off" | "locked" | "err" terug */
    static String request(Context c, String ip, String cmd) {
        try {
            JSONObject d = device(c, ip);
            String pw = d == null ? "" : d.optString("pw", "");
            String url = "http://" + ip + "/cm?"
                    + (pw.isEmpty() ? "" : "user=admin&password=" + URLEncoder.encode(pw, "UTF-8") + "&")
                    + "cmnd=" + URLEncoder.encode(cmd, "UTF-8").replace("+", "%20");
            HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
            try {
                h.setConnectTimeout(3000);
                h.setReadTimeout(4000);
                int code = h.getResponseCode();
                if (code == 401) return "locked";
                if (code >= 400) return "err";
                JSONObject r = new JSONObject(readAll(h.getInputStream()));
                if (r.has("WARNING") && !r.has("POWER") && !r.has("POWER1")) return "locked";
                String p = r.optString("POWER", r.optString("POWER1", ""));
                return "ON".equalsIgnoreCase(p) ? "on" : "OFF".equalsIgnoreCase(p) ? "off" : "err";
            } finally { h.disconnect(); }
        } catch (Exception e) { return "err"; }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }
}
