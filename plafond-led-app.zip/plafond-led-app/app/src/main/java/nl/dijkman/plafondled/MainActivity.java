package nl.dijkman.plafondled;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Toont de bedieningspagina (assets/index.html) en doet de HTTP-verzoeken naar
 * Tasmota zelf, buiten de browser om. Daardoor speelt CORS geen rol.
 */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Tasmota");
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Wordt vanuit JavaScript aangeroepen als: Tasmota.get(url, id) */
    private class Bridge {
        @JavascriptInterface
        public void get(final String url, final String id) {
            new Thread(() -> {
                boolean ok;
                String body;
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(4000);
                    c.setReadTimeout(6000);
                    int code = c.getResponseCode();
                    InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
                    body = in == null ? "" : readAll(in);
                    ok = code < 400;
                    if (!ok) body = "HTTP " + code + " " + body;
                } catch (Exception e) {
                    ok = false;
                    body = e.toString();
                } finally {
                    if (c != null) c.disconnect();
                }
                final String b64 = Base64.encodeToString(body.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                final String js = "window.__tasCb && window.__tasCb('" + id.replace("'", "") + "'," + ok + ",'" + b64 + "')";
                web.post(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
