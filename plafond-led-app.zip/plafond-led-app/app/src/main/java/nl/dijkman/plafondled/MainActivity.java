package nl.dijkman.plafondled;

import android.app.Activity;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Toont de bedieningspagina (assets/index.html) en doet de HTTP-verzoeken naar
 * Tasmota zelf, buiten de browser om. Daardoor speelt CORS geen rol.
 */
public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Tasmota");
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Stuurt een resultaat terug naar JavaScript: window.__tasCb(id, ok, base64) */
    private void callback(String id, boolean ok, String body) {
        final String b64 = Base64.encodeToString(body.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        final String js = "window.__tasCb && window.__tasCb('" + id.replace("'", "") + "'," + ok + ",'" + b64 + "')";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private class Bridge {
        /** Tasmota.get(url, id): één HTTP GET */
        @JavascriptInterface
        public void get(final String url, final String id) {
            new Thread(() -> {
                try {
                    String[] r = httpGet(url, 4000, 6000);
                    int code = Integer.parseInt(r[0]);
                    if (code < 400) callback(id, true, r[1]);
                    else callback(id, false, "HTTP " + code + " " + r[1]);
                } catch (Exception e) {
                    callback(id, false, e.toString());
                }
            }).start();
        }

        /** Tasmota.scan(id): zoekt Tasmota-apparaten in het eigen /24-netwerk */
        @JavascriptInterface
        public void scan(final String id) {
            new Thread(() -> {
                try {
                    String prefix = localPrefix();
                    JSONObject res = new JSONObject();
                    JSONArray found = new JSONArray();
                    res.put("subnet", prefix == null ? "" : prefix + "0/24");
                    if (prefix != null) {
                        ExecutorService pool = Executors.newFixedThreadPool(64);
                        List<Future<JSONObject>> jobs = new ArrayList<>();
                        for (int i = 1; i < 255; i++) {
                            final String ip = prefix + i;
                            jobs.add(pool.submit(() -> probe(ip)));
                        }
                        for (Future<JSONObject> f : jobs) {
                            try {
                                JSONObject o = f.get();
                                if (o != null) found.put(o);
                            } catch (Exception ignored) { }
                        }
                        pool.shutdown();
                        pool.awaitTermination(5, TimeUnit.SECONDS);
                    }
                    res.put("devices", found);
                    callback(id, true, res.toString());
                } catch (Exception e) {
                    callback(id, false, e.toString());
                }
            }).start();
        }
    }

    /** Vraagt "Status" op; geeft null als het geen Tasmota is */
    private static JSONObject probe(String ip) {
        try {
            String[] r = httpGet("http://" + ip + "/cm?cmnd=Status", 800, 2000);
            int code = Integer.parseInt(r[0]);
            JSONObject o = new JSONObject();
            o.put("ip", ip);
            if (code == 401) {                 // Tasmota met webwachtwoord
                if (!r[1].contains("password")) return null;
                o.put("protected", true);
                return o;
            }
            JSONObject st = new JSONObject(r[1]).optJSONObject("Status");
            if (st == null) return null;
            o.put("name", st.optString("DeviceName", ""));
            o.put("topic", st.optString("Topic", ""));
            JSONArray fn = st.optJSONArray("FriendlyName");
            StringBuilder sb = new StringBuilder();
            if (fn != null) for (int i = 0; i < fn.length(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(fn.optString(i));
            }
            o.put("friendly", sb.toString());
            o.put("power", st.opt("Power") == null ? "" : String.valueOf(st.opt("Power")));
            return o;
        } catch (Exception e) {
            return null;
        }
    }

    /** Eerste drie delen van het wifi-IP van de telefoon, bv. "10.10.100." */
    private static String localPrefix() throws Exception {
        String fallback = null;
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                String ip = a.getHostAddress();
                String p = ip.substring(0, ip.lastIndexOf('.') + 1);
                if (ni.getName().startsWith("wlan")) return p;
                if (fallback == null) fallback = p;
            }
        }
        return fallback;
    }

    /** Geeft {statuscode, body} terug */
    private static String[] httpGet(String url, int connectMs, int readMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(connectMs);
            c.setReadTimeout(readMs);
            int code = c.getResponseCode();
            InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
            return new String[]{String.valueOf(code), in == null ? "" : readAll(in)};
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
