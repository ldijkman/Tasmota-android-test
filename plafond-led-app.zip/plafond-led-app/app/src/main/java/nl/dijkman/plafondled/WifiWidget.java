package nl.dijkman.plafondled;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.widget.RemoteViews;

/**
 * Homescreen-widget: toont het huidige wifi-netwerk + IP.
 * "Wissel" opent het wifi-paneel van Android (Android 10+) of de wifi-instellingen.
 * Tik op de naam om te verversen.
 */
public class WifiWidget extends AppWidgetProvider {

    static final String ACTION_REFRESH = "nl.dijkman.plafondled.WIFI_REFRESH";

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        listenForNetworkChanges(ctx);
        RemoteViews v = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, v);
    }

    @Override
    public void onEnabled(Context ctx) {
        listenForNetworkChanges(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                ConnectivityManager cm = ctx.getSystemService(ConnectivityManager.class);
                cm.unregisterNetworkCallback(selfIntent(ctx));
            } catch (Exception ignored) { }
        }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        // Eigen verversverzoek of melding van een netwerkwijziging
        if (!AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(intent.getAction())) updateAll(ctx);
    }

    static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, WifiWidget.class));
        if (ids.length == 0) return;
        RemoteViews v = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, v);
    }

    private static PendingIntent selfIntent(Context ctx) {
        Intent i = new Intent(ctx, WifiWidget.class).setAction(ACTION_REFRESH);
        return PendingIntent.getBroadcast(ctx, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
    }

    /** Laat Android de widget seinen bij elke wifi-wijziging, ook als de app dicht is (Android 8+) */
    private static void listenForNetworkChanges(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            ConnectivityManager cm = ctx.getSystemService(ConnectivityManager.class);
            NetworkRequest req = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
            PendingIntent pi = selfIntent(ctx);
            try { cm.unregisterNetworkCallback(pi); } catch (Exception ignored) { }
            cm.registerNetworkCallback(req, pi);
        } catch (Exception ignored) { }
    }

    private static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_wifi);

        String ssid = null, ip = "";
        boolean onWifi = false;
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null && wm.isWifiEnabled()) {
                WifiInfo wi = wm.getConnectionInfo();
                if (wi != null) {
                    onWifi = wi.getIpAddress() != 0;
                    String s = wi.getSSID();
                    if (s != null && !s.contains("unknown ssid") && !s.equals("0x")) ssid = s.replace("\"", "");
                    int a = wi.getIpAddress();
                    if (a != 0) ip = (a & 255) + "." + ((a >> 8) & 255) + "." + ((a >> 16) & 255) + "." + ((a >> 24) & 255);
                }
                if (!onWifi) ssid = "Niet verbonden";
            } else {
                ssid = "Wifi staat uit";
            }
        } catch (Exception e) {
            ssid = "Wifi";
        }
        if (ssid == null) ssid = onWifi ? "Wifi verbonden" : "Wifi";
        v.setTextViewText(R.id.w_ssid, ssid);
        v.setTextViewText(R.id.w_ip, ip);

        // "Wissel": wifi-paneel (Android 10+), anders wifi-instellingen
        Intent panel = new Intent(Build.VERSION.SDK_INT >= 29
                ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setOnClickPendingIntent(R.id.w_switch, PendingIntent.getActivity(ctx, 2, panel,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));

        // Tik op naam/IP: verversen
        Intent refresh = new Intent(ctx, WifiWidget.class).setAction(ACTION_REFRESH);
        v.setOnClickPendingIntent(R.id.w_info, PendingIntent.getBroadcast(ctx, 3, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        return v;
    }
}
