# Angle Meter (Android)

A lightweight inclinometer / bubble level for Android 8.0+. Written in plain Java with no
third-party libraries, using only the Android framework.

## Features
- **Protractor mode.** Stand the phone on one of its edges against a surface to read that surface's angle (0–180°), with the complementary angle shown too.
- **Bubble level mode.** Lay the phone flat to see its X/Y tilt and total tilt on a spirit-level display.
- **Automatic switching** between the two modes, depending on how the phone is held.
- **Hold.** Tap the screen or the Hold button to freeze the reading, which helps when the screen is hard to see.
- **Zero.** Measures relative to the current position, for example the angle between two surfaces.
- **Calibrate.** Corrects for sensor bias on a known level surface. The correction is saved between launches.
- Turns green and gives a haptic tick at 0°, 90° and 180°.
- Keeps the screen awake. Uses the fused gravity sensor when the phone has one, otherwise the accelerometer with a low-pass filter.

## Build option A: Android Studio
1. Unzip the project, then open the `AngleMeter` folder in Android Studio (File → Open).
2. Wait for the Gradle sync to finish.
3. Plug in your phone with USB debugging on and press ▶ Run.
   You can also use Build → Build APK(s) and copy the APK to your phone.

## Build option B: GitHub (no local setup)
1. Push this folder to a new GitHub repository.
2. The included workflow (`.github/workflows/build.yml`) builds automatically.
3. Open Actions → the latest run → download **AngleMeter-apk**.
4. Install it on your phone. You'll need to allow "install unknown apps" for your file manager or browser.

The release APK is signed with the debug key so it installs directly. Set up your own
signing key before publishing it to the Play Store.

## Accuracy tips
- Calibrate once on a surface you know is level, such as one checked with a real spirit level.
- To check calibration, measure the same surface, rotate the phone 180° and measure again. The two readings should match.
- Phone cases and camera bumps can tilt the phone. In bubble level mode, use the phone's flat back without the case. In protractor mode, use a straight edge.
