package com.example.anglemeter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Angle meter / inclinometer.
 *
 * - Phone standing on an edge  -> protractor mode: angle of the edge the phone rests on.
 * - Phone lying flat           -> bubble-level mode: tilt along X and Y.
 * The mode switches automatically (with hysteresis) based on how far the screen
 * is tilted away from horizontal.
 */
public class MainActivity extends Activity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor sensor;
    private boolean usingGravitySensor;

    private final float[] g = new float[3];
    private boolean hasData;
    private boolean flatMode;

    private SharedPreferences prefs;
    private AngleView angleView;
    private Button holdButton;
    private Button zeroButton;

    // Permanent calibration (sensor bias), saved across launches.
    private float calEdge, calX, calY;

    // Temporary relative zero.
    private boolean zeroActive;
    private float zeroEdge, zeroX, zeroY;

    // Latest raw readings (before calibration / zero).
    private float rawEdge, rawX, rawY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        prefs = getSharedPreferences("angle_meter", MODE_PRIVATE);
        calEdge = prefs.getFloat("calEdge", 0f);
        calX = prefs.getFloat("calX", 0f);
        calY = prefs.getFloat("calY", 0f);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY);
        usingGravitySensor = sensor != null;
        if (sensor == null) sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        angleView = new AngleView(this);
        angleView.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleHold(); }
        });

        holdButton = makeButton("Hold", new View.OnClickListener() {
            @Override public void onClick(View v) { toggleHold(); }
        });
        zeroButton = makeButton("Zero", new View.OnClickListener() {
            @Override public void onClick(View v) { toggleZero(); }
        });
        Button calButton = makeButton("Calibrate", new View.OnClickListener() {
            @Override public void onClick(View v) { showCalibrateDialog(); }
        });

        float dp = getResources().getDisplayMetrics().density;
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        buttons.setPadding((int) (12 * dp), (int) (8 * dp), (int) (12 * dp), (int) (24 * dp));
        for (Button b : new Button[]{holdButton, zeroButton, calButton}) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, (int) (52 * dp), 1f);
            lp.setMarginStart((int) (6 * dp));
            lp.setMarginEnd((int) (6 * dp));
            buttons.addView(b, lp);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#101418"));
        root.addView(angleView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(buttons, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);

        if (sensor == null) {
            Toast.makeText(this, "This device has no accelerometer.", Toast.LENGTH_LONG).show();
        }
    }

    private Button makeButton(String label, View.OnClickListener onClick) {
        float dp = getResources().getDisplayMetrics().density;
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16f);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(14 * dp);
        bg.setColor(Color.parseColor("#1F2730"));
        bg.setStroke((int) (1 * dp), Color.parseColor("#33414F"));
        b.setBackground(bg);
        b.setOnClickListener(onClick);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (sensor != null) sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float[] v = event.values;
        if (!hasData) {
            g[0] = v[0]; g[1] = v[1]; g[2] = v[2];
            hasData = true;
        } else {
            // Low-pass filter. The raw accelerometer is noisier, so smooth it harder.
            float a = usingGravitySensor ? 0.25f : 0.08f;
            for (int i = 0; i < 3; i++) g[i] += a * (v[i] - g[i]);
        }
        if (angleView.held) return;

        float gx = g[0], gy = g[1], gz = g[2];
        float norm = (float) Math.sqrt(gx * gx + gy * gy + gz * gz);
        if (norm < 1f) return; // free fall / bad data

        // How far the screen is from facing straight up/down (0 = flat).
        float screenTilt = (float) Math.toDegrees(Math.asin(clamp((float) Math.sqrt(gx * gx + gy * gy) / norm, 0f, 1f)));
        flatMode = flatMode ? screenTilt < 50f : screenTilt < 40f;

        // Edge angle: rotation of the phone in the screen plane, clockwise positive, 0 = upright.
        rawEdge = (float) Math.toDegrees(Math.atan2(-gx, gy));
        // Flat tilt per axis.
        rawX = (float) Math.toDegrees(Math.asin(clamp(gx / norm, -1f, 1f)));
        rawY = (float) Math.toDegrees(Math.asin(clamp(gy / norm, -1f, 1f)));

        render();
    }

    private void render() {
        if (flatMode) {
            float x = rawX - calX;
            float y = rawY - calY;
            if (zeroActive) { x -= zeroX; y -= zeroY; }
            angleView.showFlat(x, y, zeroActive);
        } else {
            float a = wrap180(rawEdge - calEdge);
            if (zeroActive) a = wrap180(a - zeroEdge);
            angleView.showEdge(a, zeroActive);
        }
    }

    private void toggleHold() {
        angleView.held = !angleView.held;
        holdButton.setText(angleView.held ? "Release" : "Hold");
        angleView.invalidate();
    }

    private void toggleZero() {
        if (zeroActive) {
            zeroActive = false;
            zeroButton.setText("Zero");
        } else {
            zeroEdge = wrap180(rawEdge - calEdge);
            zeroX = rawX - calX;
            zeroY = rawY - calY;
            zeroActive = true;
            zeroButton.setText("Clear zero");
            Toast.makeText(this, "Measuring relative to the current position", Toast.LENGTH_SHORT).show();
        }
        if (!angleView.held) render();
    }

    private void showCalibrateDialog() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Calibrate")
                .setMessage("Place the phone on a surface you know is perfectly level — flat on its back, "
                        + "or standing on its edge — keep it still, then tap Calibrate.\n\n"
                        + "Tip: for best accuracy, calibrate, rotate the phone 180°, and check it reads ~0.")
                .setPositiveButton("Calibrate", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { calibrate(); }
                })
                .setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { resetCalibration(); }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void calibrate() {
        if (!hasData) return;
        if (flatMode) {
            calX = rawX;
            calY = rawY;
        } else {
            // Snap to the nearest 90° (upright, sideways, upside-down).
            float nearest = Math.round(rawEdge / 90f) * 90f;
            calEdge = rawEdge - nearest;
        }
        saveCalibration();
        Toast.makeText(this, "Calibrated", Toast.LENGTH_SHORT).show();
        if (!angleView.held) render();
    }

    private void resetCalibration() {
        calEdge = 0f; calX = 0f; calY = 0f;
        saveCalibration();
        Toast.makeText(this, "Calibration reset", Toast.LENGTH_SHORT).show();
        if (!angleView.held) render();
    }

    private void saveCalibration() {
        prefs.edit().putFloat("calEdge", calEdge).putFloat("calX", calX).putFloat("calY", calY).apply();
    }

    static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    static float wrap180(float a) {
        float r = a % 360f;
        if (r > 180f) r -= 360f;
        if (r < -180f) r += 360f;
        return r;
    }

    static boolean isNear(float value, float target, float tol) { return Math.abs(value - target) <= tol; }
}
