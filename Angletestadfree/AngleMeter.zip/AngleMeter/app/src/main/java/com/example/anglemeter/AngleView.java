package com.example.anglemeter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.View;

import java.util.Locale;

/** Draws either a protractor dial (edge mode) or a bubble level (flat mode). */
public class AngleView extends View {

    static final float LEVEL_TOL = 0.3f;
    static final float MAX_FLAT_DEG = 15f;

    boolean held;

    private boolean flat;
    private float edgeAngle, tiltX, tiltY;
    private boolean relative;
    private boolean wasLevel;

    private final float dp;

    private final int green = Color.parseColor("#4ADE80");
    private final int amber = Color.parseColor("#FBBF24");
    private final int dim = Color.parseColor("#5B6875");
    private final int faint = Color.parseColor("#2A343E");
    private final int white = Color.WHITE;

    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bigText = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AngleView(Context context) {
        super(context);
        dp = getResources().getDisplayMetrics().density;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        bigText.setTextAlign(Paint.Align.CENTER);
        bigText.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        bigText.setColor(white);
    }

    private static boolean edgeLevel(float absA) {
        return MainActivity.isNear(absA, 0f, LEVEL_TOL)
                || MainActivity.isNear(absA, 90f, LEVEL_TOL)
                || MainActivity.isNear(absA, 180f, LEVEL_TOL);
    }

    void showEdge(float angle, boolean rel) {
        flat = false; edgeAngle = angle; relative = rel;
        hapticOnLevel(edgeLevel(Math.abs(angle)));
        invalidate();
    }

    void showFlat(float x, float y, boolean rel) {
        flat = true; tiltX = x; tiltY = y; relative = rel;
        hapticOnLevel(Math.abs(x) <= LEVEL_TOL && Math.abs(y) <= LEVEL_TOL);
        invalidate();
    }

    private void hapticOnLevel(boolean level) {
        if (level && !wasLevel) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        wasLevel = level;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (flat) drawFlat(canvas); else drawEdge(canvas);
        drawBadges(canvas);
    }

    // ---------------------------------------------------------------- edge / protractor

    private void drawEdge(Canvas c) {
        float cx = getWidth() / 2f;
        float cy = getHeight() * 0.46f;
        float r = Math.min(getWidth(), getHeight()) * 0.40f;
        float a = edgeAngle;
        float absA = Math.abs(a);
        int accent = edgeLevel(absA) ? green : amber;

        // Outer ring.
        stroke.setColor(faint); stroke.setStrokeWidth(2 * dp);
        c.drawCircle(cx, cy, r, stroke);

        // Ticks fixed to the phone. 0 at the bottom, 90 at the sides, 180 at the top.
        text.setColor(dim); text.setTextSize(13 * dp);
        for (int deg = -175; deg <= 180; deg += 5) {
            double rad = Math.toRadians(deg);
            float dx = (float) Math.sin(rad), dy = (float) Math.cos(rad);
            boolean major = deg % 30 == 0;
            boolean mid = deg % 15 == 0;
            float len = major ? 18 * dp : (mid ? 12 * dp : 7 * dp);
            stroke.setColor(major ? white : dim);
            stroke.setStrokeWidth(major ? 2.5f * dp : 1.5f * dp);
            c.drawLine(cx + dx * r, cy + dy * r, cx + dx * (r - len), cy + dy * (r - len), stroke);
            if (major) {
                float lr = r - 34 * dp;
                c.drawText(String.valueOf(Math.abs(deg)), cx + dx * lr, cy + dy * lr + 5 * dp, text);
            }
        }

        // World horizon (perpendicular to the plumb line) and plumb needle.
        double rad = Math.toRadians(a);
        float nx = (float) Math.sin(rad), ny = (float) Math.cos(rad);
        stroke.setColor(faint); stroke.setStrokeWidth(2 * dp);
        c.drawLine(cx - ny * r * 0.9f, cy + nx * r * 0.9f, cx + ny * r * 0.9f, cy - nx * r * 0.9f, stroke);

        float tip = r - 22 * dp;
        stroke.setColor(accent); stroke.setStrokeWidth(5 * dp);
        c.drawLine(cx, cy, cx + nx * tip, cy + ny * tip, stroke);
        stroke.setStrokeWidth(3 * dp);
        c.drawLine(cx, cy, cx - nx * r * 0.25f, cy - ny * r * 0.25f, stroke);
        fill.setColor(accent);
        c.drawCircle(cx, cy, 7 * dp, fill);
        c.drawCircle(cx + nx * tip, cy + ny * tip, 6 * dp, fill);

        // Readout.
        float ty = cy + r + 70 * dp;
        bigText.setTextSize(64 * dp);
        c.drawText(formatDeg(absA), cx, ty, bigText);
        text.setColor(dim); text.setTextSize(15 * dp);
        float complement = absA <= 90f ? 90f - absA : absA - 90f;
        String dir = absA < 0.05f ? "" : (a > 0 ? "  ↻" : "  ↺");
        c.drawText("Complement " + formatDeg(complement) + dir, cx, ty + 30 * dp, text);

        text.setTextSize(13 * dp);
        c.drawText("Stand the phone on its edge against the surface", cx, 36 * dp, text);
    }

    // ---------------------------------------------------------------- flat / bubble level

    private void drawFlat(Canvas c) {
        float cx = getWidth() / 2f;
        float cy = getHeight() * 0.42f;
        float r = Math.min(getWidth(), getHeight()) * 0.40f;
        boolean level = Math.abs(tiltX) <= LEVEL_TOL && Math.abs(tiltY) <= LEVEL_TOL;
        int accent = level ? green : amber;

        // Rings at 2°, 5°, 10° and the 15° edge.
        stroke.setStrokeWidth(1.5f * dp);
        text.setTextSize(11 * dp); text.setColor(dim);
        for (int deg : new int[]{2, 5, 10, 15}) {
            float rr = r * deg / MAX_FLAT_DEG;
            stroke.setColor(deg == 15 ? dim : faint);
            c.drawCircle(cx, cy, rr, stroke);
            c.drawText(deg + "°", cx + rr * 0.707f + 12 * dp, cy - rr * 0.707f - 4 * dp, text);
        }
        stroke.setColor(faint);
        c.drawLine(cx - r, cy, cx + r, cy, stroke);
        c.drawLine(cx, cy - r, cx, cy + r, stroke);

        // Bubble moves toward the raised side, like a real spirit level.
        float bubbleR = 22 * dp;
        float bx = tiltX / MAX_FLAT_DEG * r;
        float by = -tiltY / MAX_FLAT_DEG * r;
        float dist = (float) Math.sqrt(bx * bx + by * by);
        float maxDist = r - bubbleR;
        if (dist > maxDist) { bx *= maxDist / dist; by *= maxDist / dist; }
        fill.setColor(accent); fill.setAlpha(70);
        c.drawCircle(cx + bx, cy + by, bubbleR, fill);
        fill.setAlpha(255);
        stroke.setColor(accent); stroke.setStrokeWidth(3 * dp);
        c.drawCircle(cx + bx, cy + by, bubbleR, stroke);

        // Centre target.
        stroke.setColor(white); stroke.setStrokeWidth(1.5f * dp);
        c.drawCircle(cx, cy, bubbleR + 3 * dp, stroke);

        // Readout.
        float total = (float) Math.sqrt(tiltX * tiltX + tiltY * tiltY);
        float ty = cy + r + 70 * dp;
        bigText.setTextSize(64 * dp);
        c.drawText(formatDeg(total), cx, ty, bigText);
        text.setColor(dim); text.setTextSize(15 * dp);
        c.drawText("X " + formatSigned(tiltX) + "     Y " + formatSigned(tiltY), cx, ty + 30 * dp, text);

        text.setTextSize(13 * dp);
        c.drawText("Lay the phone flat on the surface", cx, 36 * dp, text);
    }

    // ---------------------------------------------------------------- badges

    private void drawBadges(Canvas c) {
        text.setTextSize(13 * dp);
        float x = getWidth() - 16 * dp;
        float y = 70 * dp;
        if (held) x = drawBadge(c, "HOLD", amber, x, y);
        if (relative) drawBadge(c, "REL", green, x, y);
    }

    private float drawBadge(Canvas c, String label, int color, float x, float y) {
        float w = text.measureText(label) + 20 * dp;
        fill.setColor(color); fill.setAlpha(40);
        c.drawRoundRect(x - w, y - 18 * dp, x, y + 8 * dp, 8 * dp, 8 * dp, fill);
        fill.setAlpha(255);
        text.setColor(color);
        c.drawText(label, x - w / 2, y, text);
        return x - w - 8 * dp;
    }

    private static float roundTenth(float v) {
        float r = Math.round(v * 10f) / 10f;
        return r == 0f ? 0f : r; // avoids "-0.0"
    }

    private static String formatDeg(float v) { return String.format(Locale.getDefault(), "%.1f°", roundTenth(v)); }
    private static String formatSigned(float v) { return String.format(Locale.getDefault(), "%+.1f°", roundTenth(v)); }
}
